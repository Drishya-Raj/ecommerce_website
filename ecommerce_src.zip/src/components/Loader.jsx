import React from 'react'

function Loading() {
    
  return (
    <div className='loader'>Loading <i className="fa-solid fa-spinner fa-spin "></i></div>
  )
}

export default Loading;