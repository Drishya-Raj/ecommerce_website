// import { onAuthStateChanged } from 'firebase/auth';
// import { auth } from '../firebase';

// export const checkAuthentication = (setIsAuthenticated) => {
//   onAuthStateChanged(auth, (user) => {
//     if (user) {
//       // User is signed in.
//       setIsAuthenticated(true);
//     } else {
//       // No user is signed in.
//       setIsAuthenticated(false);
//     }
//   });
// };
