export const messages = [
    // Success
    {
      maincolor: '#43dc23',
      secondarycolor: '#197d04',
      symbol: 'symbol',
      title: 'Success !!!',
      text: 'Login to continue',
    },
    // Failed
    {
      maincolor: '#f92525',
      secondarycolor: '#890a0a',
      symbol: 'symbol',
      title: 'Error!',
      text: 'Error occured, Try again',
    },
  ];