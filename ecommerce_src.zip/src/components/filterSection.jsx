// import clear from '../assets/images/clear.png';
// import { categories, brands, features, conditions } from './listItems';
// import { items } from './listItems';
// import { useState } from 'react';
// import { FilterSidebar } from './filterSidebar';
// import TextInput from './textInput';

// const FilterSection = () => {
  
//     return (
//             <ul className='filter'>
//                 {filteredItems.map((item) => (
//                     <li key={item.id}>
//                         {item.category} - {item.brand} - ${item.price} -{item.features}
//                     </li>
//                 ))}
//                 {/* <p className="clr">Clear all filter</p> */}
//             </ul>

      
//     )
// }
// export default FilterSection;