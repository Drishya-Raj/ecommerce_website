import arrow from '../assets/images/arrow.png';
import listview from '../assets/images/listview.png';
import gridview from '../assets/images/gridview.png';
import smartphone from '../assets/images/1.png';
import mob1 from '../assets/images/mob1.png';
import mobile from '../assets/images/mobile.png';
import laptop from '../assets/images/laptop.png';
import watch from '../assets/images/watch.png';
import headset from '../assets/images/whiteheadPhones.png';
import image from '../assets/images/rating.png';
import dot from '../assets/images/Dot.png';
import dot2 from '../assets/images/Dot.png';
import fav from '../assets/images/favorite_border.png';
import user from '../assets/images/user.png';
import tshirts from '../assets/images/image 34.png';
import image35 from '../assets/images/image 35.png';
import image36 from '../assets/images/image 36.png';
import image37 from '../assets/images/image 40.png';
import image38 from '../assets/images/image 38.png';
import image39 from '../assets/images/image 39.png';
import tick from '../assets/images/tick.png';
import imagee from '../assets/images/image 37.png';
import coat from '../assets/images/coat.png';
import tshirt from '../assets/images/tshirt.png';
import suite from '../assets/images/suite.png';
import blue from '../assets/images/blue.png';
import bag from '../assets/images/bag.png';
import rating from '../assets/images/rating.png';
import msg from '../assets/images/message.png';
import basket from '../assets/images/basket.png';
import lamp from '../assets/images/lamp.png';
import backarrow from '../assets/images/backarrow.png';
import star from '../assets/images/rating.png';
import mob3 from '../assets/images/mob3.png';
import camera from '../assets/images/camera.png';
import emirates from '../assets/images/iconemirates.png';
import austrailia from '../assets/images/iconaustralia.png';
import china from '../assets/images/iconchina.png';
import russia from '../assets/images/iconrussia.png';
import denmark from '../assets/images/icondenmark.png';
import america from '../assets/images/iconusa.png';
import italy from '../assets/images/iconitaly.png'
import france from '../assets/images/france.png';
import britain from '../assets/images/britain.png';
import logo from '../assets/images/logo-colored.png';
import facebook from '../assets/images/facebook.png';
import twitter from '../assets/images/twitter.png';
import linkedin from '../assets/images/link.png';
import youtube from '../assets/images/youtube.png';
import appstore from '../assets/images/appstore.png';
import playstore from '../assets/images/playstore.png';
import cart from '../assets/images/cart.png';
import orders from '../assets/images/wish.png';
import profile from '../assets/images/profile.png';
import wallet from '../assets/images/mensWallet.png';
import headphones from '../assets/images/whiteheadPhones.png';
import trouser from '../assets/images/trousers.png';
import jug from '../assets/images/jug.png';
import mensWallet from '../assets/images/wallet.png';
import rimg from '../assets/images/img.jpg';
import germany from '../assets/images/germany.png';
import verify from '../assets/images/verified_user.png';
import language from '../assets/images/language.png';
import bg from '../assets/images/bg1.png';
import chair from '../assets/images/chair.png';
import kitchen from '../assets/images/bed.png';
import juicer from '../assets/images/juicer.png';
import juicer2 from '../assets/images/juicer2.png';
import appliance from '../assets/images/wallet.png';
import pot from '../assets/images/pot.png';
import plant from '../assets/images/plant.png';
import trousers from '../assets/images/trousers.png';
import whiteheadsets from '../assets/images/whiteheadPhones.png';
import rect from '../assets/images/image102.png';
import industry from '../assets/images/industry.png';
import search from '../assets/images/Vectorsearch.png';
import rainbow from '../assets/images/rainbow.png';
import bucket from '../assets/images/bucket.png';
import workers from '../assets/images/workers.png';
import aeroplane from '../assets/images/aeroplane.png';
import send from '../assets/images/send.png';
import security from '../assets/images/Vector.png';
import lock from '../assets/images/lock.png';
import van from '../assets/images/van.png';
import mobile1 from '../assets/images/mobile.png';
import mobile2 from '../assets/images/mob1.png'
import check from '../assets/images/check.png';
import hide from '../assets/images/hide.png';
import view from '../assets/images/view.png';
import fav1 from '../assets/images/fav.svg';
import notfound from '../assets/images/notfound.jpg';
import favorite from '../assets/images/favorite.svg';
import payment from '../assets/images/payment.png';
import orangered from '../assets/images/orangered.png';
import paypal from '../assets/images/paypal.png';
import visa from '../assets/images/visa.png';
import ipay from '../assets/images/ipay.png';

export {
  arrow,
  notfound,
  orangered,
  payment,
  paypal,
  visa,
  ipay,
  cart,
  hide,
  fav1,
  favorite,
  view,
  rect,
  check,
  lock,
  mobile1,
  mobile2,
  van,
  security,
  industry,
  search,
  rainbow,
  bucket,
  workers,
  aeroplane,
  send,
  bg,
  whiteheadsets,
  chair,
  trousers,
  kitchen,
  juicer,
  juicer2,
  appliance,
  pot,
  plant,
  rimg,
  germany,
  verify,
  language,
  wallet,
  headphones,
  trouser,
  jug,
  mensWallet,
  orders,
  logo,
  profile,
  facebook,
  twitter,
  linkedin,
  youtube,
  appstore,
  playstore,
  camera,
  mob3,
  star,
  emirates,
  austrailia,
  china,
  russia,
  denmark,
  america,
  italy,
  france,
  britain,
  rating,
  msg,
  lamp,
  backarrow,
  basket,
  coat,
  tshirt,
  suite,
  blue,
  bag,
  listview,
  gridview,
  smartphone,
  mob1,
  mobile,
  laptop,
  watch,
  headset,
  image,
  dot,
  dot2,
  fav,
  user,
  tshirts,
  image35,
  image36,
  image37,
  image38,
  image39,
  tick,
  imagee
};
